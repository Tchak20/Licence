
 <?php $__env->startSection('content'); ?>
<!--- Modification --->

<div class="card-content w-50 mx-auto mt-100">
      <div class="card-header">
        <h5 class="card-title">Ajouter un symptôme</h5>
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('home.update', $maladie->id)); ?>" method="POST" enctype="multipart/form-data" >
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="mb-3">
            <label for="name" class="form-label">Nom</label>
            <input class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" type="text" name="nom_maladie" value="<?php echo e(old('nom_maladie', $maladie->nom_maladie)); ?>" placeholder="Nom de la maladie">
            <?php $__errorArgs = ['nom_maladie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <input type="text" hidden name="maladies_id" value="<?php echo e($maladie->id); ?>" >
          <div class="mb-3">
            <label for="image" class="form-label">Select Image:</label>
            <input type="file" name="image" id="image"  class="mon-champ-de-fichier form-control @error('image) is-invalid @enderror">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" id="description" name="description" value="<?php echo e(old('description', $maladie->description)); ?>" placeholder="Description de la maladie"></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
           
          <div class="mb-3">
            <label for="traitement" class="form-label">Traitement</label>
            <textarea class="form-control" id="traitement" name="traitements" placeholder="Traitement"><?php echo e(old('traitements', $traitement )); ?></textarea>
            <?php $__errorArgs = ['traitement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="mb-3">
            <label for="prevention" class="form-label">Prévention</label>
            <textarea class="form-control" id="prevention" name="prevention" placeholder="Prévention"><?php echo e(old('prevention', $prevention )); ?></textarea>
            <?php $__errorArgs = ['prevention'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="mb-3">
            <label for="autres" class="form-label">Autres</label>
            <textarea class="form-control" id="autres" name="autres" placeholder="Autres..."><?php echo e(old('autres' , $autres )); ?></textarea>
            <?php $__errorArgs = ['autres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-primary" type="submit">Envoyer</button>
          </div>
        </form>
      </div>
     
    </div>

    <script>
      document.getElementById('mon-champ-de-fichier').defaultValue = "<?php echo e(old('image'), $maladie->image); ?>";
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tchak\Desktop\doctor_admin\resources\views/edit.blade.php ENDPATH**/ ?>