
 <?php $__env->startSection('content'); ?>
<!--- Modification --->

<div class="card-content w-50 mx-auto mt-100">
      <div class="card-header">
        <h5 class="card-title">Ajouter un symptôme</h5>
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('symptomes.update', $symptome->id)); ?>" method="POST" enctype="multipart/form-data" >
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="mb-3">
            <label for="name" class="form-label">Nom</label>
            <input class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" type="text" name="nom_symptome" value="<?php echo e($nom); ?>" placeholder="Nom de la maladie">
            <?php $__errorArgs = ['nom_maladie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="d-grid gap-2">
            <button class="btn btn-primary" type="submit">Envoyer</button>
          </div>
        </form>
      </div>
     
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tchak\Desktop\doctor_admin\resources\views/edit_symp.blade.php ENDPATH**/ ?>