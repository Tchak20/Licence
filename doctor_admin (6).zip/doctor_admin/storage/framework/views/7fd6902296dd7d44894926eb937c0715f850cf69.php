

<?php $__env->startSection('content'); ?>

<?php if(session()->has('info')): ?>
    <div class="bg-success text-white p-3">
    <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>
    <div class="card-content w-50 mx-auto mt-100 mb-100">
      <div class="card-header">
        <h5 class="card-title">Ajouter un symptôme </h5>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('symptomes.store')); ?>" method="POST" enctype="multipart/form-data" >
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="name" class="form-label">Nom</label>
            <input class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" type="text" name="nom_symptome"  placeholder="Nom du symptôme ">
            <?php $__errorArgs = ['nom_symptome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="d-grid gap-2">
            <button class="btn btn-primary" type="submit">Envoyer</button>
          </div>
        </form>
      </div>
      
      <div class="row w-100 mx-auto mt-6">
            <div class="col align-item-right">
                <table class="table shadow">
                    <thead>
                        <tr>
                            <th scope="col">Elément</th>
                            <th scope="col"></th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $symptomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                        <td><?php echo e($symptome->nom_symptome); ?></td>
                           
                                <td>
                               <a href="<?php echo e(route('symptomes.edit', $symptome->id)); ?>"  data-bs-toggle="tooltip" data-bs-placement="top" title="Ajouter" data-id="$symptome->nom"> <button type="button" class="btn btn-warning">
                                    <i class="bi bi-pencil"></i> Modifier
                                </button></a>
                                </td>
                                <td>
                                <form action="<?php echo e(route('symptomes.destroy', $symptome->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                   <button type="submit" class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Supprimer
                                   </button> 
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
            <footer class="mt-5">
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <?php echo e($symptomes->links('vendor.pagination.bootstrap-5')); ?>

                    </ul>
                </nav>
            </footer>
        </div>

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tchak\Desktop\doctor_admin\resources\views/symptome_create.blade.php ENDPATH**/ ?>